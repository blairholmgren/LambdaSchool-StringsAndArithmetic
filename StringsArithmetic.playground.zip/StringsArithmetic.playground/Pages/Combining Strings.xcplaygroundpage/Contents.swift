//: [Previous](@previous)
/*:
 ## String Concatenation
 Create a constant for your favorite vacation destination. Using string concatenation, print out a string that says "I love to travel to [favorite travel destination]."
 */
let favoriteDestination = "Ironwood, Michigan"
print("I love to travel to \(favoriteDestination).")

/*:
 ## String Interpolation
 Using the constant you created above, print out the same string: "I love to travel to [favorite travel destination]." using string interpolation
 */
let string = "I love to travel to" + " " + favoriteDestination + "."
print(string)

//: page 2 of 3 | [Next: Arithmetic](@next)
