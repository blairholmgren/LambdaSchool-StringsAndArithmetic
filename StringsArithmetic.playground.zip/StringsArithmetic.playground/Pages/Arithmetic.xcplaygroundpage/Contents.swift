//: [Previous](@previous)
/*:
 ## Calorie Goal
 Below you have constants for the number of calories you burned each day over the last week. Using simple arithmetic find the average number of calories burned. Add 100 calories to the average and use string interpolation to print out "Your new move goal for the week is [your calculated goal].
 */
var Sunday = 1500
var Monday = 1200
var Tuesday = 1350
var Wednesday = 1430
var Thursday = 1900
var Friday = 1380
var Saturday = 1470

let total = Sunday + Monday + Tuesday + Wednesday + Thursday + Friday + Saturday
let average = total / 7
let goal = average + 100
print(goal)



//: page 3 of 3
