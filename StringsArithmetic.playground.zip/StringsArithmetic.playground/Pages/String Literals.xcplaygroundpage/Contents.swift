/*:
## String Literals
 Create a string literal constant introducing yourself. Your introduction should include your name, where you're from, what you like to do for fun, and why you decided to do Lambda School.

 */
print("""
Hi, my name is Blair!
I am from Battleground, WA. I like to play basketball, ski, and of course, code.
I chose to attend Lambda School because it provides an opportunity to enter the programming field in a faster fashion than traditional methods.
""")

/*:
 ## Multiline String Literal
 Create a multiline string literal constant of a 1-paragraph letter to Lambda School on why you'd be a great candidate for the program.
 */
print("""
I believe that I would make for a great candidate for the Lambda School program due to my strong willingness and desire to learn and discover new concepts.
This trait I think is what has made me a valuable employee and student in the past, and will continue to do so into my career ahead.
""")

//: page 1 of 3 | [Next: Combining Strings](@next)
